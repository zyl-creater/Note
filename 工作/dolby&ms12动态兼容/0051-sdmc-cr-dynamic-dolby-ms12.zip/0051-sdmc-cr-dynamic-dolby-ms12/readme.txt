[补丁名字]: 
    0051-sdmc-cr-dynamic-dolby-ms12
[创建者]: 
    zhuyuelin
[创建时间]: 
    20250329
[功能描述]: 
    
[patch 来源]: 
    
[验证平台]: 
    
[注意事项]: 
    
